package com.majer.phone02;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MyLoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_login);

        //아이디 정보를 읽어 온다.
        //정당한 아이디인지 확인한다.
        EditText  idtext;
        EditText  pwtext;

        Button  login2 = findViewById(R.id.login2);

        login2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EditText  idtext = (EditText) findViewById(R.id.idText);
                EditText  pwtext = (EditText) findViewById(R.id.pwText);

                String id = idtext.getText().toString();
                String pw = pwtext.getText().toString();

                if(id.equals("root") && pw.equals("pass")) {

                    Toast.makeText(getApplicationContext(),"메모장 화면으로 이동", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(getApplicationContext(), MemoActivity.class);
                    startActivity(intent);

                } else {

                    Toast.makeText(getApplicationContext(),"로그인 실패", Toast.LENGTH_SHORT).show();
                }
                //Dialog 화면으로 로그인 결과 출력


            }
        });
    }

}

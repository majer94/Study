package com.majer.phone02;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class ButtonActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_button);

        //1. 레이아웃에 있는 View(뷰)를 선택
        Button  toast = findViewById(R.id.toast);

        //2. button을 가지고 와서 액션처리
        toast.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"내가 토스트에요", Toast.LENGTH_LONG).show();
            }
        });
        //3. 토스트를 띄운다.

        Button  toast2 = findViewById(R.id.toast2);

        toast2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"내가 토스트2에요", Toast.LENGTH_SHORT).show();
            }
        });

        Button  tel = findViewById(R.id.tel);

        tel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"전화하기", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("tel:010-7337-1247"));
                startActivity(intent);
            }
        });

        Button  find = findViewById(R.id.find);

        find.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"검색하기", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://m.naver.com"));
                startActivity(intent);
            }
        });

        Button  login = findViewById(R.id.login2);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"로그인하기", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
            }
        });

        Button  mylogin = findViewById(R.id.mylogin);

        mylogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"내 로그인화면으로 이동", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(getApplicationContext(), MyLoginActivity.class);
                startActivity(intent);
            }
        });

    }
}

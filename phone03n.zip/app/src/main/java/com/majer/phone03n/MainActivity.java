package com.majer.phone03n;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        1. 처리할 버튼을 찾아라
        Button restart = findViewById(R.id.bt_restart);

//        2. 버튼을 클릭했을때 처리할 것을 셋팅
        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                3. 처리할 내용은 DietActivity를 시작
//                   1) 화면에서 처리하고자 하는 View를 찾으세요.
//                   2) 클릭했을 때, DietActivity가 열리도록 처리
//                      액티비티를 넘길 때는...
//                      2-1) 액티비티를 넘길 수 있는 부품을 셋팅.
//                           Intent복사(new) 해서 가지고 온 다음
//                           현재 액티비티(getApplicationContext())-> 가야할 액티비티 셋팅
//                      2-2) intent부품 시작
                Toast.makeText(getApplicationContext(),"다이어트 화면으로 이동",Toast.LENGTH_LONG).show();
                Intent godiet = new Intent(getApplicationContext(),DietActivity.class);
                startActivity(godiet);
            }
        });



    }
}

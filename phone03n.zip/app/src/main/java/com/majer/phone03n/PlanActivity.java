package com.majer.phone03n;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class PlanActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plan);

        //1. 처리할 버튼을 찾아라
        Button gostart = findViewById(R.id.bt_gostart);

        //2. 버튼을 클릭했을때 처리할 것을 셋팅
        gostart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //3. 처리할 내용은 DietActivity를 시작

                Toast.makeText(getApplicationContext(),"처음 화면으로 이동",Toast.LENGTH_LONG).show();
                Intent gomain = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(gomain);
            }
        });
    }
}

package com.choiur.dicegame;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.ButtonBarLayout;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button bt_start = (Button) findViewById(R.id.bt_start);
        bt_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String str_player1 = "";
                String str_player2 = "";

                EditText in_player1 = (EditText) findViewById(R.id.txt_player1);
                EditText in_player2 = (EditText) findViewById(R.id.txt_player2);

                str_player1 = in_player1.getText().toString();
                str_player2 = in_player2.getText().toString();

                if(str_player1.equals("") || str_player2.equals("")) {
                    Toast.makeText(getApplicationContext(), "PLAYER 이름을 입력하세요", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "주사위 게임을 시작합니다", Toast.LENGTH_LONG).show();

                    Intent start = new Intent(getApplicationContext(), DiceActivity.class);
                    start.putExtra("PLAYER1", str_player1);
                    start.putExtra("PLAYER2", str_player2);
                    startActivity(start);
                }

            }
        });
    }
}

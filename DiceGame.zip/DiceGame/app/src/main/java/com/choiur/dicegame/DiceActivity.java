package com.choiur.dicegame;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class DiceActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dice);

        int rdice1, rdice2;
        int bdice1, bdice2;

        Intent intent = getIntent();
        String str_player1 = intent.getStringExtra("PLAYER1");
        String str_player2 = intent.getStringExtra("PLAYER2");

        TextView txt_player1 = (TextView) findViewById(R.id.player1_name);
        txt_player1.setText(str_player1);

        TextView txt_player2 = (TextView) findViewById(R.id.player2_name);
        txt_player2.setText(str_player2);

        Random rdice = new Random();
        Random bdice = new Random();

        ImageView img_rdice1;
        img_rdice1 = (ImageView) findViewById(R.id.img_rdice1);

        switch (rdice1 = rdice.nextInt(6)) {
            case 0 :
                img_rdice1.setImageResource(R.drawable.dice01);
                break;
            case 1 :
                img_rdice1.setImageResource(R.drawable.dice02);
                break;
            case 2 :
                img_rdice1.setImageResource(R.drawable.dice03);
                break;
            case 3 :
                img_rdice1.setImageResource(R.drawable.dice04);
                break;
            case 4 :
                img_rdice1.setImageResource(R.drawable.dice05);
                break;
            case 5 :
                img_rdice1.setImageResource(R.drawable.dice06);
                break;
        }

        ImageView img_rdice2;
        img_rdice2 = (ImageView) findViewById(R.id.img_rdice2);
        switch (rdice2 = rdice.nextInt(6)) {
            case 0 :
                img_rdice2.setImageResource(R.drawable.dice01);
                break;
            case 1 :
                img_rdice2.setImageResource(R.drawable.dice02);
                break;
            case 2 :
                img_rdice2.setImageResource(R.drawable.dice03);
                break;
            case 3 :
                img_rdice2.setImageResource(R.drawable.dice04);
                break;
            case 4 :
                img_rdice2.setImageResource(R.drawable.dice05);
                break;
            case 5 :
                img_rdice2.setImageResource(R.drawable.dice06);
                break;
        }

        ImageView img_bdice1;
        img_bdice1 = (ImageView) findViewById(R.id.img_bdice1);
        switch (bdice1 = bdice.nextInt(6)) {
            case 0 :
                img_bdice1.setImageResource(R.drawable.dice01);
                break;
            case 1 :
                img_bdice1.setImageResource(R.drawable.dice02);
                break;
            case 2 :
                img_bdice1.setImageResource(R.drawable.dice03);
                break;
            case 3 :
                img_bdice1.setImageResource(R.drawable.dice04);
                break;
            case 4 :
                img_bdice1.setImageResource(R.drawable.dice05);
                break;
            case 5 :
                img_bdice1.setImageResource(R.drawable.dice06);
                break;
        }

        ImageView img_bdice2;
        img_bdice2 = (ImageView) findViewById(R.id.img_bdice2);
        switch (bdice2 = bdice.nextInt(6)) {
            case 0 :
                img_bdice2.setImageResource(R.drawable.dice01);
                break;
            case 1 :
                img_bdice2.setImageResource(R.drawable.dice02);
                break;
            case 2 :
                img_bdice2.setImageResource(R.drawable.dice03);
                break;
            case 3 :
                img_bdice2.setImageResource(R.drawable.dice04);
                break;
            case 4 :
                img_bdice2.setImageResource(R.drawable.dice05);
                break;
            case 5 :
                img_bdice2.setImageResource(R.drawable.dice06);
                break;
        }

        // 주사위 게임의 결과를 화면에 출력
        TextView txt_result = (TextView) findViewById(R.id.txt_result);

        int rdice_total = rdice1 + rdice2;
        int bdice_total = bdice1 + bdice2;

        if (rdice_total == bdice_total) {

            int rdice_multiply = rdice1 * rdice2;
            int bdice_multiply = bdice1 * bdice2;

            if (rdice_multiply > bdice_multiply) {
                txt_result.setText(str_player1 + " 승리~ " + str_player2 + " 밥사세요~");
            } else {
                if(rdice_multiply < bdice_multiply) {
                    txt_result.setText(str_player2 + " 승리~ " + str_player1 + " 밥사세요~");
                } else{
                    txt_result.setText("무승부! 아쉽지만 ㅇㄴㅁㅇㅁ오늘은 더치페이~");

                    ImageView img_result = (ImageView) findViewById(R.id.img_result);
                    img_result.setImageResource(R.drawable.image_same);
                }
            }

        } else {

            if (rdice_total > bdice_total) {
              txt_result.setText(str_player1 + " 승리~" + str_player2 + " 밥사세요~");
            } else  {
              txt_result.setText(str_player2 + " 승리~" + str_player1 + " 밥사세요~" );
            }

        }

        final Button bt_replay = (Button) findViewById(R.id.bt_replay);
        bt_replay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "게임을 다시 시작합니다.", Toast.LENGTH_LONG).show();
                Intent replay = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(replay);
            }
        });


    }
}

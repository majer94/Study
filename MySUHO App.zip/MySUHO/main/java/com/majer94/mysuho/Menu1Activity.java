package com.majer94.mysuho;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Menu1Activity extends AppCompatActivity {

    ImageView img_menu1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu1);

//        Button bt_img3 = (Button) findViewById(R.id.bt_menu1_3);
//        Button bt_img4 = (Button) findViewById(R.id.bt_menu1_4);
//        Button bt_img5 = (Button) findViewById(R.id.bt_menu1_5);

        Button bt_img1 = (Button) findViewById(R.id.bt_menu1_1);
        bt_img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView img_menu1 = (ImageView) findViewById(R.id.img_menu1);

                //수정할 부분
                img_menu1.setImageResource(R.drawable.sh_menu1_1);

                TextView txt_menu1 = (TextView) findViewById(R.id.txt_menu1);

                //수정할 부분
                StringBuilder sb_string = new StringBuilder();
                sb_string.append("만삭사진 (2017.10.01) \n");
                sb_string.append("친구의 마음에 드는 만삭사진을 따라서 \n");
                sb_string.append("부부가 다정히 손을 잡고, 아기 신발을 \n");
                sb_string.append("손가락에 걸었다. 우리도 느낌 아니까~");
                //수정할 부분

                String str_info = sb_string.toString();
                txt_menu1.setText(str_info);
            }
        });

        Button bt_img2 = (Button) findViewById(R.id.bt_menu1_2);
        bt_img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView img_menu1 = (ImageView) findViewById(R.id.img_menu1);

                //수정할 부분
                img_menu1.setImageResource(R.drawable.sh_menu1_2);

                TextView txt_menu1 = (TextView) findViewById(R.id.txt_menu1);

                //수정할 부분
                StringBuilder sb_string = new StringBuilder();
                sb_string.append("만삭사진 (2017.10.01) \n");
                sb_string.append("몸이 많이 무거워져서 힘들어했지만, \n");
                sb_string.append("와이프는 역시 사진 찍기를 좋아한다. \n");
                sb_string.append("수호 초음파 사진을 들고 다정히 한 컷~");
                //수정할 부분

                String str_info = sb_string.toString();
                txt_menu1.setText(str_info);
            }
        });

        Button bt_img3 = (Button) findViewById(R.id.bt_menu1_3);
        bt_img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView img_menu1 = (ImageView) findViewById(R.id.img_menu1);

                //수정할 부분
                img_menu1.setImageResource(R.drawable.sh_menu1_3);

                TextView txt_menu1 = (TextView) findViewById(R.id.txt_menu1);

                //수정할 부분
                StringBuilder sb_string = new StringBuilder();
                sb_string.append("산후조리원에서 (2018.12.25) \n");
                sb_string.append("크리스마스를 산후 조리원에서...\n");
                sb_string.append("인형을 꼭 안고 한 컷~ \n");
                sb_string.append("태어난지 딱 10일이 지났다.");
                //수정할 부분

                String str_info = sb_string.toString();
                txt_menu1.setText(str_info);
            }
        });

        Button bt_img4 = (Button) findViewById(R.id.bt_menu1_4);
        bt_img4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView img_menu1 = (ImageView) findViewById(R.id.img_menu1);

                //수정할 부분
                img_menu1.setImageResource(R.drawable.sh_menu1_4);

                TextView txt_menu1 = (TextView) findViewById(R.id.txt_menu1);

                //수정할 부분
                StringBuilder sb_string = new StringBuilder();
                sb_string.append("혼자 분유 먹기 (2018.3.10) \n");
                sb_string.append("친구에게 받은 선물. 득템~\n");
                sb_string.append("혼자서도 분유를 잘 먹는다.\n");
                sb_string.append("계속 들어주지 않아도 되니 좋다.");
                //수정할 부분

                String str_info = sb_string.toString();
                txt_menu1.setText(str_info);
            }
        });

        Button bt_img5 = (Button) findViewById(R.id.bt_menu1_5);
        bt_img5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView img_menu1 = (ImageView) findViewById(R.id.img_menu1);

                //수정할 부분
                img_menu1.setImageResource(R.drawable.sh_menu1_5);

                TextView txt_menu1 = (TextView) findViewById(R.id.txt_menu1);

                //수정할 부분
                StringBuilder sb_string = new StringBuilder();
                sb_string.append("유모차 (2018.3.15) \n");
                sb_string.append("새로 산 유모차를 타고 동네 한 바퀴\n");
                sb_string.append("어느새 세상 모르고 잠들어 있다.\n");
                sb_string.append("추운 날씨에도 산책이 좋은가 보다.");
                //수정할 부분

                String str_info = sb_string.toString();
                txt_menu1.setText(str_info);
            }
        });

        Button bt_go_list = (Button) findViewById(R.id.bt_go_list1);
        bt_go_list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast msg_no = Toast.makeText(getApplicationContext(), "메뉴화면으로 돌아갑니다.", Toast.LENGTH_SHORT);
                msg_no.setGravity(Gravity.CENTER, 0, 0);
                msg_no.show();

                Intent go_list = new Intent(getApplicationContext(), ListActivity.class);
                startActivity(go_list);
            }
        });

    }
}

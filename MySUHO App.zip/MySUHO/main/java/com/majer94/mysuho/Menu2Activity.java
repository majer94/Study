package com.majer94.mysuho;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Menu2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu2);

        Button bt_img1 = (Button) findViewById(R.id.bt_menu2_1);
        bt_img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView img_menu2 = (ImageView) findViewById(R.id.img_menu2);

                //수정할 부분
                img_menu2.setImageResource(R.drawable.sh_menu2_1);

                TextView txt_menu2 = (TextView) findViewById(R.id.txt_menu2);

                //수정할 부분
                StringBuilder sb_string = new StringBuilder();
                sb_string.append("기어가다 (2018.5.20) \n");
                sb_string.append("이제 조금씩 기어다니기 시작.\n");
                sb_string.append("매트도 깔고 주변 물건도 조금씩\n");
                sb_string.append("정리하기 시작했다.");
                //수정할 부분

                String str_info = sb_string.toString();
                txt_menu2.setText(str_info);
            }
        });

        Button bt_img2 = (Button) findViewById(R.id.bt_menu2_2);
        bt_img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView img_menu2 = (ImageView) findViewById(R.id.img_menu2);

                //수정할 부분
                img_menu2.setImageResource(R.drawable.sh_menu2_2);

                TextView txt_menu2 = (TextView) findViewById(R.id.txt_menu2);

                //수정할 부분
                StringBuilder sb_string = new StringBuilder();
                sb_string.append("여름휴가 (2018.7.10) \n");
                sb_string.append("풀빌라에서 여름휴가를...\n");
                sb_string.append("물놀이를 무지 좋아한다. \n");
                sb_string.append("엄마를 닮았나보다.");
                //수정할 부분

                String str_info = sb_string.toString();
                txt_menu2.setText(str_info);
            }
        });

        Button bt_img3 = (Button) findViewById(R.id.bt_menu2_3);
        bt_img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView img_menu2 = (ImageView) findViewById(R.id.img_menu2);

                //수정할 부분
                img_menu2.setImageResource(R.drawable.sh_menu2_3);

                TextView txt_menu2 = (TextView) findViewById(R.id.txt_menu2);

                //수정할 부분
                StringBuilder sb_string = new StringBuilder();
                sb_string.append("200일 기념사진 \n");
                sb_string.append("한복이 잘 어울린다. \n");
                sb_string.append("귀한 집 도련님같이 나왔다.\n");
                sb_string.append("내 눈에만 그렇게 보이는건가...ㅋㅋ");
                //수정할 부분

                String str_info = sb_string.toString();
                txt_menu2.setText(str_info);
            }
        });

        Button bt_img4 = (Button) findViewById(R.id.bt_menu2_4);
        bt_img4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView img_menu2 = (ImageView) findViewById(R.id.img_menu2);

                //수정할 부분
                img_menu2.setImageResource(R.drawable.sh_menu2_4);

                TextView txt_menu2 = (TextView) findViewById(R.id.txt_menu2);

                //수정할 부분
                StringBuilder sb_string = new StringBuilder();
                sb_string.append("친구와 함께\n");
                sb_string.append("둘이 제법 친해진거 같다.\n");
                sb_string.append("자세는 조금 거만해보인다.\n");
                sb_string.append("언제나 이렇게 사이좋게 지내렴.");
                //수정할 부분

                String str_info = sb_string.toString();
                txt_menu2.setText(str_info);
            }
        });

        Button bt_img5 = (Button) findViewById(R.id.bt_menu2_5);
        bt_img5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView img_menu2 = (ImageView) findViewById(R.id.img_menu2);

                //수정할 부분
                img_menu2.setImageResource(R.drawable.sh_menu2_5);

                TextView txt_menu2 = (TextView) findViewById(R.id.txt_menu2);

                //수정할 부분
                StringBuilder sb_string = new StringBuilder();
                sb_string.append("속초여행\n");
                sb_string.append("호수공원 주변을 걷다가 \n");
                sb_string.append("민들레가 있어 수호에게 보여주니\n");
                sb_string.append("무척 관심을 가진다. 후~ 후~");
                //수정할 부분

                String str_info = sb_string.toString();
                txt_menu2.setText(str_info);
            }
        });

        Button bt_go_list = (Button) findViewById(R.id.bt_go_list2);
        bt_go_list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast msg_no = Toast.makeText(getApplicationContext(), "메뉴화면으로 돌아갑니다.", Toast.LENGTH_SHORT);
                msg_no.setGravity(Gravity.CENTER, 0, 0);
                msg_no.show();

                Intent go_list = new Intent(getApplicationContext(), ListActivity.class);
                startActivity(go_list);
            }
        });
    }
}

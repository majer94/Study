package com.majer94.mysuho;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class ListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        Button bt_menu1 = (Button) findViewById(R.id.bt_go_menu1);
        bt_menu1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent go_menu1 = new Intent(getApplicationContext(), Menu1Activity.class);
                startActivity(go_menu1);
            }
        });

        Button bt_menu2 = (Button) findViewById(R.id.bt_go_menu2);
        bt_menu2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent go_menu2 = new Intent(getApplicationContext(), Menu2Activity.class);
                startActivity(go_menu2);
            }
        });

        Button bt_menu3 = (Button) findViewById(R.id.bt_go_menu3);
        bt_menu3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent go_menu3 = new Intent(getApplicationContext(), Menu3Activity.class);
                startActivity(go_menu3);
            }
        });

        Button bt_menu4 = (Button) findViewById(R.id.bt_go_menu4);
        bt_menu4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent go_menu4 = new Intent(getApplicationContext(), DiaryActivity.class);
                startActivity(go_menu4);
            }
        });
    }
}

package com.majer94.mysuho;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        ImageView img_sh_main = (ImageView) findViewById(R.id.img_sh_main);

        Button bt_login = (Button) findViewById(R.id.bt_login);
        bt_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EditText id = (EditText) findViewById(R.id.text_id);
                EditText pw = (EditText) findViewById(R.id.text_pw);

                String sid = id.getText().toString();
                String spw = pw.getText().toString();

                if (sid.equals("suho") && spw.equals("171215")) {
                    Toast msg_ok = Toast.makeText(getApplicationContext(), "로그인 성공! 메뉴 화면으로 이동합니다.", Toast.LENGTH_LONG);
                    msg_ok.setGravity(Gravity.CENTER, 0, 0);
                    msg_ok.show();

                    Intent go_list = new Intent(getApplicationContext(), ListActivity.class);
                    startActivity(go_list);
                } else {
                    Toast msg_no = Toast.makeText(getApplicationContext(), "아이디 또는 패스워드가 일치하지 않습니다.", Toast.LENGTH_LONG);
                    msg_no.setGravity(Gravity.CENTER, 0, 0);
                    msg_no.show();
                }

            }
        });
    }
}

package com.majer94.mysuho;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

public class DiaryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diary);

        Button bt_clear = (Button) findViewById(R.id.bt_clear);
        bt_clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText txt_date = (EditText) findViewById(R.id.txt_date);
                txt_date.setText("");

                EditText txt_title = (EditText) findViewById(R.id.txt_title);
                txt_title.setText("");

                EditText txt_content = (EditText) findViewById(R.id.txt_content);
                txt_content.setText("");
            }
        });

        Button bt_read = (Button) findViewById(R.id.bt_read);
        bt_read.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InputStream in;

                EditText txt_date = (EditText) findViewById(R.id.txt_date);
                String f_name = txt_date.getText().toString() + ".txt";

                try {
                    in = openFileInput(f_name);
                } catch (FileNotFoundException e) {
                    Toast msg_err = Toast.makeText(getApplicationContext(), "해당 일자의 일기는 없습니다.", Toast.LENGTH_SHORT);
                    msg_err.setGravity(Gravity.CENTER, 0, 0);
                    msg_err.show();

                    Log.e("Diary File Not Found", e.getMessage());
                    return;
                }

                EditText txt_title = (EditText) findViewById(R.id.txt_title);
                txt_title.setText("");
                EditText txt_content = (EditText) findViewById(R.id.txt_content);
                txt_content.setText("");

                try {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in, "UTF-8"));
                    String str_line;

                    if ((str_line = reader.readLine()) != null) {
                        txt_title.append(str_line);
                        txt_title.append("\n");
                    }

                    while ((str_line = reader.readLine()) != null) {
                        txt_content.append(str_line);
                        txt_content.append("\n");
                    }

                    reader.close();

                } catch (IOException e) {
                    Log.e("Diary File Read", e.getMessage());
                    return;
                }
            }
        });

        Button bt_write = (Button) findViewById(R.id.bt_write);
        bt_write.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EditText txt_date = (EditText) findViewById(R.id.txt_date);
                String f_name = txt_date.getText().toString() + ".txt";
                if (f_name.length() == 0) {
                    Toast msg_err1 = Toast.makeText(getApplicationContext(), "읽어올 일기의 날짜를 입력하세요.", Toast.LENGTH_SHORT);
                    msg_err1.setGravity(Gravity.CENTER, 0, 0);
                    msg_err1.show();
                    return;
                }

                EditText txt_title = (EditText) findViewById(R.id.txt_title);
                String f_title = txt_title.getText().toString();
                if (f_title.length() == 0) {
                    Toast msg_err2 = Toast.makeText(getApplicationContext(), "일기 제목을 입력하세요.", Toast.LENGTH_SHORT);
                    msg_err2.setGravity(Gravity.CENTER, 0, 0);
                    msg_err2.show();
                    return;
                }

                EditText txt_content = (EditText) findViewById(R.id.txt_content);
                String f_content = txt_content.getText().toString();
                if (f_content.length() == 0) {
                    Toast msg_err3 = Toast.makeText(getApplicationContext(), "일기 내용을 입력하세요.", Toast.LENGTH_SHORT);
                    msg_err3.setGravity(Gravity.CENTER, 0, 0);
                    msg_err3.show();
                    return;
                }

                try {
                    OutputStream out = openFileOutput(f_name, MODE_PRIVATE);
                    PrintWriter writer = new PrintWriter(new OutputStreamWriter(out, "UTF-8"));

                    writer.append(f_title);
                    writer.append("\n");
                    writer.append(f_content);
                    writer.close();

                    Toast msg_ok = Toast.makeText(getApplicationContext(), "일기가 정상적으로 저장되었습니다.", Toast.LENGTH_SHORT);
                    msg_ok.setGravity(Gravity.CENTER, 0, 0);
                    msg_ok.show();

                } catch (IOException e) {
                    Log.e("Diary File", e.getMessage());
                }

            }
        });

        Button bt_go_list = (Button) findViewById(R.id.bt_go_list4);
        bt_go_list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast msg_no = Toast.makeText(getApplicationContext(), "메뉴화면으로 돌아갑니다.", Toast.LENGTH_SHORT);
                msg_no.setGravity(Gravity.CENTER, 0, 0);
                msg_no.show();

                Intent go_list = new Intent(getApplicationContext(), ListActivity.class);
                startActivity(go_list);
            }
        });
    }
}
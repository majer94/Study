package com.majer94.mysuho;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Menu3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu3);

        Button bt_img1 = (Button) findViewById(R.id.bt_menu3_1);
        bt_img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView img_menu3 = (ImageView) findViewById(R.id.img_menu3);

                //수정할 부분
                img_menu3.setImageResource(R.drawable.sh_menu3_1);

                TextView txt_menu3 = (TextView) findViewById(R.id.txt_menu3);

                //수정할 부분
                StringBuilder sb_string = new StringBuilder();
                sb_string.append("첫돌 기념사진\n");
                sb_string.append("스튜디오에서 첫돌 기념사진을\n");
                sb_string.append("찍는데 이날따라 기분이 안좋은가 보다. \n");
                sb_string.append("찍는 동안 엄청 고생했다.");
                //수정할 부분

                String str_info = sb_string.toString();
                txt_menu3.setText(str_info);
            }
        });

        Button bt_img2 = (Button) findViewById(R.id.bt_menu3_2);
        bt_img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView img_menu3 = (ImageView) findViewById(R.id.img_menu3);

                //수정할 부분
                img_menu3.setImageResource(R.drawable.sh_menu3_2);

                TextView txt_menu3 = (TextView) findViewById(R.id.txt_menu3);

                //수정할 부분
                StringBuilder sb_string = new StringBuilder();
                sb_string.append("벨리댄서\n");
                sb_string.append("문화센터 놀이교실에서 벨리댄서를... \n");
                sb_string.append("이제는 제법 걸으려고도 하고 \n");
                sb_string.append("나름 춤동작도 조금씩 흉내낸다.");
                //수정할 부분

                String str_info = sb_string.toString();
                txt_menu3.setText(str_info);
            }
        });

        Button bt_img3 = (Button) findViewById(R.id.bt_menu3_3);
        bt_img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView img_menu3 = (ImageView) findViewById(R.id.img_menu3);

                //수정할 부분
                img_menu3.setImageResource(R.drawable.sh_menu3_3);

                TextView txt_menu3 = (TextView) findViewById(R.id.txt_menu3);

                //수정할 부분
                StringBuilder sb_string = new StringBuilder();
                sb_string.append("코스모스\n");
                sb_string.append("집 앞 공원에 코드모스가 활짝~\n");
                sb_string.append("이제 가을이 성큼 다가왔다.\n");
                sb_string.append("수호도 가을과 코스모스를 좋아하나보다.");
                //수정할 부분

                String str_info = sb_string.toString();
                txt_menu3.setText(str_info);
            }
        });

        Button bt_img4 = (Button) findViewById(R.id.bt_menu3_4);
        bt_img4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView img_menu3 = (ImageView) findViewById(R.id.img_menu3);

                //수정할 부분
                img_menu3.setImageResource(R.drawable.sh_menu3_4);

                TextView txt_menu3 = (TextView) findViewById(R.id.txt_menu3);

                //수정할 부분
                StringBuilder sb_string = new StringBuilder();
                sb_string.append("문화센터 놀이교실\n");
                sb_string.append("현대백화점 문화센터 놀이교실\n");
                sb_string.append("이것저것 재미있는 놀이들을 많이 한다.\n");
                sb_string.append("내가 어릴적에도 이런게 있었더라면...");
                //수정할 부분

                String str_info = sb_string.toString();
                txt_menu3.setText(str_info);
            }
        });

        Button bt_img5 = (Button) findViewById(R.id.bt_menu3_5);
        bt_img5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView img_menu3 = (ImageView) findViewById(R.id.img_menu3);

                //수정할 부분
                img_menu3.setImageResource(R.drawable.sh_menu3_5);

                TextView txt_menu3 = (TextView) findViewById(R.id.txt_menu3);

                //수정할 부분
                StringBuilder sb_string = new StringBuilder();
                sb_string.append("첫돌 기념사진 \n");
                sb_string.append("스튜디오에서 첫돌 기념사진을\n");
                sb_string.append("사진 찍느라 엄청 고생했지만...\n");
                sb_string.append("이 사진 하나는 잘 건진거 같다.");
                //수정할 부분

                String str_info = sb_string.toString();
                txt_menu3.setText(str_info);
            }
        });

        Button bt_go_list = (Button) findViewById(R.id.bt_go_list3);
        bt_go_list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast msg_no = Toast.makeText(getApplicationContext(), "메뉴화면으로 돌아갑니다.", Toast.LENGTH_SHORT);
                msg_no.setGravity(Gravity.CENTER, 0, 0);
                msg_no.show();

                Intent go_list = new Intent(getApplicationContext(), ListActivity.class);
                startActivity(go_list);
            }
        });
    }
}

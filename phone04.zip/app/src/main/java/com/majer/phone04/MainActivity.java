package com.majer.phone04;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //1. 배치에 있던 Button을 찾아서,
        //2. Button을 눌렀을 때, 액션처리 셋팅
        //3. 액션처리 구체적인 내용
        //   Cal액티비티로 넘김

        Button cal = findViewById(R.id.button1);
        cal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gocal = new Intent(getApplicationContext(), CalActivity.class);
                startActivity(gocal);
            }
        });

        Button login = findViewById(R.id.button2);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gologin = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(gologin);
            }
        });



    }
}

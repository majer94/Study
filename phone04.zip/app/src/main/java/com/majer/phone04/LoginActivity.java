package com.majer.phone04;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button bt_login =(Button) findViewById(R.id.bt_login);

        bt_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String  id;
                String  pw;

                EditText tf_id = findViewById(R.id.tf_id);
                EditText tf_pw = findViewById(R.id.tf_pw);

                id = tf_id.getText().toString();
                pw = tf_pw.getText().toString();

                if(id.equals("admin") && pw.equals("1234")) {
                    Intent gologinok = new Intent(getApplicationContext(), LoginokActivity.class);
                    startActivity(gologinok);

                } else {
                    Intent gologinnot = new Intent(getApplicationContext(), LoginnotActivity.class);
                    startActivity(gologinnot);
                }


            }
        });

    }
}

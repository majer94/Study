package com.majer.phone04;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class CalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cal);

        Button bt_pls = findViewById(R.id.bt_pls);

        bt_pls.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int num1, num2;
                int result;

                EditText tf_num1 = findViewById(R.id.tf_num1);
                EditText tf_num2 = findViewById(R.id.tf_num2);

                num1 = Integer.parseInt(tf_num1.getText().toString());
                num2 = Integer.parseInt(tf_num2.getText().toString());

                result = num1 + num2;

                Toast.makeText(getApplicationContext(),"두 수의 덧셈은 " + result, Toast.LENGTH_LONG).show();


                TextView tf_result = (TextView) findViewById(R.id.tf_result);
                tf_result.setText(Integer.toString(result));

            }
        });

        Button bt_mis = findViewById(R.id.bt_mis);

        bt_mis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int num1, num2;
                int result;

                EditText tf_num1 = findViewById(R.id.tf_num1);
                EditText tf_num2 = findViewById(R.id.tf_num2);

                num1 = Integer.parseInt(tf_num1.getText().toString());
                num2 = Integer.parseInt(tf_num2.getText().toString());

                result = num1 - num2;

                Toast.makeText(getApplicationContext(),"두 수의 뺼셈은 " + result, Toast.LENGTH_LONG).show();


//                TextView tf_result = findViewById(R.id.tf_result);
//
//                tf_result.setText(result);

            }
        });

        Button bt_mul = findViewById(R.id.bt_mul);

        bt_mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int num1, num2;
                int result;

                EditText tf_num1 = findViewById(R.id.tf_num1);
                EditText tf_num2 = findViewById(R.id.tf_num2);

                num1 = Integer.parseInt(tf_num1.getText().toString());
                num2 = Integer.parseInt(tf_num2.getText().toString());

                result = num1 * num2;

                Toast.makeText(getApplicationContext(),"두 수의 곱셈은 " + result, Toast.LENGTH_LONG).show();


//                TextView tf_result = findViewById(R.id.tf_result);
//
//                tf_result.setText(result);

            }
        });

        Button bt_div = findViewById(R.id.bt_div);

        bt_div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int num1, num2;
                int result;

                EditText tf_num1 = findViewById(R.id.tf_num1);
                EditText tf_num2 = findViewById(R.id.tf_num2);

                num1 = Integer.parseInt(tf_num1.getText().toString());
                num2 = Integer.parseInt(tf_num2.getText().toString());

                result = num1 / num2;

                Toast.makeText(getApplicationContext(),"두 수의 나눗셈은 " + result, Toast.LENGTH_LONG).show();


//                TextView tf_result = findViewById(R.id.tf_result);
//
//                tf_result.setText(result);

            }
        });


        Button bt_main = findViewById(R.id.bt_gomain);

        bt_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gomain = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(gomain);
            }
        });


    }
}
